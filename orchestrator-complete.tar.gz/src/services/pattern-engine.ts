/**
 * Pattern Recognition Engine
 * The brain that understands emotional sequences and triggers interventions
 */

import dotenv from 'dotenv';
dotenv.config();

import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

interface EmotionEvent {
  session_id: string;
  tenant_id: string;
  emotion: string;
  confidence: number;
  behavior: string;
  timestamp: string;
  metadata?: any;
}

interface Pattern {
  sequence: string[];
  threshold: number;
  intervention: string;
  cooldown: number;
}

// Start simple - these are our initial patterns
const PATTERNS: Pattern[] = [
  // Discount Modal - price sensitivity
  {
    sequence: ['price_shock'],
    threshold: 70,
    intervention: 'discount_modal',
    cooldown: 600000 // 10 minutes
  },
  {
    sequence: ['sticker_shock'],
    threshold: 70,
    intervention: 'discount_modal',
    cooldown: 600000
  },

  // Trust Badges - skepticism
  {
    sequence: ['skeptical'],
    threshold: 65,
    intervention: 'trust_badges',
    cooldown: 300000 // 5 minutes
  },
  {
    sequence: ['evaluation'],
    threshold: 60,
    intervention: 'trust_badges',
    cooldown: 300000
  },

  // Urgency Banner - hesitation
  {
    sequence: ['hesitation'],
    threshold: 70,
    intervention: 'urgency_banner',
    cooldown: 600000
  },
  {
    sequence: ['cart_review'],
    threshold: 65,
    intervention: 'urgency_banner',
    cooldown: 600000
  },

  // Social Toast - evaluation phase
  {
    sequence: ['evaluation'],
    threshold: 60,
    intervention: 'social_toast',
    cooldown: 300000
  },
  {
    sequence: ['comparison_shopping'],
    threshold: 70,
    intervention: 'social_toast',
    cooldown: 300000
  },

  // Help Chat - confusion/frustration
  {
    sequence: ['confusion'],
    threshold: 65,
    intervention: 'help_chat',
    cooldown: 300000
  },
  {
    sequence: ['frustration'],
    threshold: 70,
    intervention: 'help_chat',
    cooldown: 300000
  },
  {
    sequence: ['frustration', 'frustration', 'frustration'],
    threshold: 70,
    intervention: 'help_chat',
    cooldown: 300000
  },

  // Value Highlight - cart hesitation
  {
    sequence: ['cart_hesitation'],
    threshold: 65,
    intervention: 'value_highlight',
    cooldown: 600000
  },

  // Comparison Modal - shopping around
  {
    sequence: ['comparison_shopping'],
    threshold: 70,
    intervention: 'comparison_modal',
    cooldown: 600000
  },
  {
    sequence: ['anxiety'],
    threshold: 65,
    intervention: 'comparison_modal',
    cooldown: 600000
  },

  // Exit Intent - abandonment risk
  {
    sequence: ['abandonment_intent'],
    threshold: 80,
    intervention: 'exit_intent',
    cooldown: 86400000 // 24 hours
  },
  {
    sequence: ['exit_risk'],
    threshold: 85,
    intervention: 'exit_intent',
    cooldown: 86400000
  }
];

class PatternEngine {
  private sessionPatterns: Map<string, EmotionEvent[]> = new Map();
  private interventionHistory: Map<string, Map<string, number>> = new Map();

  /**
   * Process incoming emotion event
   */
  async processEmotion(event: EmotionEvent): Promise<string | null> {
    const sessionId = event.session_id;

    // Get or create session history
    if (!this.sessionPatterns.has(sessionId)) {
      this.sessionPatterns.set(sessionId, []);
    }

    const history = this.sessionPatterns.get(sessionId)!;
    history.push(event);

    // Keep only last 20 emotions per session
    if (history.length > 20) {
      history.shift();
    }

    // Check for pattern matches
    const intervention = this.checkPatterns(sessionId, history);

    if (intervention) {
      // Record intervention firing
      await this.recordIntervention(sessionId, event.tenant_id, intervention);
      return intervention;
    }

    return null;
  }

  /**
   * Check if current emotion sequence matches any patterns
   */
  private checkPatterns(sessionId: string, history: EmotionEvent[]): string | null {
    // Get intervention history for this session
    const sessionInterventions = this.interventionHistory.get(sessionId) || new Map();

    for (const pattern of PATTERNS) {
      // Check cooldown
      const lastFired = sessionInterventions.get(pattern.intervention) || 0;
      if (Date.now() - lastFired < pattern.cooldown) {
        continue; // Still in cooldown
      }

      // Check if pattern matches recent emotions
      if (this.matchesPattern(history, pattern)) {
        // Update intervention history
        if (!this.interventionHistory.has(sessionId)) {
          this.interventionHistory.set(sessionId, new Map());
        }
        this.interventionHistory.get(sessionId)!.set(pattern.intervention, Date.now());

        return pattern.intervention;
      }
    }

    return null;
  }

  /**
   * Check if emotion history matches a pattern
   */
  private matchesPattern(history: EmotionEvent[], pattern: Pattern): boolean {
    if (history.length < pattern.sequence.length) {
      return false;
    }

    // Get last N emotions where N is pattern length
    const recent = history.slice(-pattern.sequence.length);

    // Check if emotions match and meet confidence threshold
    for (let i = 0; i < pattern.sequence.length; i++) {
      if (recent[i].emotion !== pattern.sequence[i]) {
        return false;
      }
      if (recent[i].confidence < pattern.threshold) {
        return false;
      }
    }

    return true;
  }

  /**
   * Record intervention in database
   */
  private async recordIntervention(sessionId: string, tenantId: string, intervention: string) {
    try {
      await supabase.from('intervention_events').insert({
        session_id: sessionId,
        tenant_id: tenantId,
        intervention_type: intervention,
        triggered_at: new Date().toISOString(),
        source: 'pattern_engine_v1'
      });
    } catch (error) {
      console.error('Failed to record intervention:', error);
    }
  }

  /**
   * Get statistics for pattern performance
   */
  async getPatternStats(tenantId: string, timeWindow: number = 86400000) {
    const since = new Date(Date.now() - timeWindow).toISOString();

    const { data: interventions } = await supabase
      .from('intervention_events')
      .select('*')
      .eq('tenant_id', tenantId)
      .gte('triggered_at', since);

    const { data: interactions } = await supabase
      .from('intervention_events')
      .select('*')
      .eq('tenant_id', tenantId)
      .eq('interacted', true)
      .gte('triggered_at', since);

    return {
      total_fired: interventions?.length || 0,
      total_interacted: interactions?.length || 0,
      success_rate: interventions?.length ?
        ((interactions?.length || 0) / interventions.length) : 0,
      by_type: this.groupByType(interventions || [])
    };
  }

  private groupByType(interventions: any[]) {
    const grouped: Record<string, number> = {};
    for (const intervention of interventions) {
      grouped[intervention.intervention_type] =
        (grouped[intervention.intervention_type] || 0) + 1;
    }
    return grouped;
  }

  /**
   * Clean up old sessions (run periodically)
   */
  cleanup() {
    const oneHourAgo = Date.now() - 3600000;

    for (const [sessionId, history] of this.sessionPatterns.entries()) {
      const lastEvent = history[history.length - 1];
      if (lastEvent && new Date(lastEvent.timestamp).getTime() < oneHourAgo) {
        this.sessionPatterns.delete(sessionId);
        this.interventionHistory.delete(sessionId);
      }
    }
  }

  /**
   * Analyze pattern for a session and emotion
   * This is the method called by the server
   */
  async analyzePattern(sessionId: string, emotion: string, tenantId: string = 'demo'): Promise<string | null> {
    const event: EmotionEvent = {
      session_id: sessionId,
      tenant_id: tenantId,
      emotion: emotion,
      confidence: 80, // Use percentage format to match pattern thresholds
      behavior: 'unknown',
      timestamp: new Date().toISOString()
    };
    return await this.processEmotion(event);
  }
}

// Export singleton instance
export const patternEngine = new PatternEngine();

// Clean up old sessions every 10 minutes
setInterval(() => {
  patternEngine.cleanup();
}, 600000);