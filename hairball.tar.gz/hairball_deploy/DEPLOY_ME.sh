#!/bin/bash

echo "
🚀 SENTIENTIQ EASY DEPLOY
═══════════════════════════

No AWS knowledge required.
Just follow the prompts.
"

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 not found. Installing..."
    sudo apt-get update
    sudo apt-get install -y python3 python3-pip python3-venv
fi

# Check Docker
if ! command -v docker &> /dev/null; then
    echo "📦 Installing Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker $USER
    echo "⚠️  Docker installed. Please logout and login again, then re-run this script."
    exit 1
fi

# Check Docker Compose
if ! command -v docker-compose &> /dev/null; then
    echo "📦 Installing Docker Compose..."
    sudo apt-get install -y docker-compose
fi

echo "
Step 1: Setting up Python environment
──────────────────────────────────────
"

cd backend
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

echo "
Step 2: Starting Docker containers
───────────────────────────────────
"

cd ../infrastructure
docker-compose up -d

echo "
Step 3: Waiting for services
─────────────────────────────
"

# Simple wait
echo "Waiting 30 seconds for everything to start..."
sleep 30

echo "
Step 4: Starting the API
─────────────────────────
"

cd ../backend
source venv/bin/activate

# Run in background with nohup
nohup python3 main.py > ~/sentientiq_api.log 2>&1 &
echo $! > ~/sentientiq_api.pid

echo "
✅ SENTIENTIQ DEPLOYED!
═══════════════════════

API running at: http://$(curl -s ifconfig.me):8000
API logs: ~/sentientiq_api.log
API PID: $(cat ~/sentientiq_api.pid)

To check if it's working:
curl http://localhost:8000

To see logs:
tail -f ~/sentientiq_api.log

To stop:
kill $(cat ~/sentientiq_api.pid)
cd infrastructure && docker-compose down

THE MOAT IS ACCUMULATING.
"
